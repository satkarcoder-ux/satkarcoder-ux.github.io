import { triggerConfetti } from './animations.js';
import { playMusic } from './audio_manager.js';

const btnYes = document.getElementById('btn-yes');
const btnNo = document.getElementById('btn-no');
const questionContainer = document.getElementById('question-container');
const successContainer = document.getElementById('success-container');


let noClickCount = 0;
const messages = [
    "No 💔",
    "Are you sure? 🥺",
    "Really sure? 😢",
    "Pookie please? 🎀",
    "Just think about it 🥞",
    "If you say no, I'll be sad 🥀",
    "I'll be very sad... 🌧️",
    "I'll be very very sad... 💔",
    "Ok fine, I'll stop asking...",
    "Just kidding, say YES! ❤️"
];


const moveNoButton = () => {





    

    const maxX = window.innerWidth - btnNo.offsetWidth - 20;
    const maxY = window.innerHeight - btnNo.offsetHeight - 20;
    
    const randomX = Math.random() * (window.innerWidth * 0.6) - (window.innerWidth * 0.3);
    const randomY = Math.random() * (window.innerHeight * 0.6) - (window.innerHeight * 0.3);
    

    btnNo.style.position = 'fixed';
    

    const centerX = window.innerWidth / 2;
    const centerY = window.innerHeight / 2;
    
    btnNo.style.left = `${centerX + randomX}px`;
    btnNo.style.top = `${centerY + randomY}px`;
};



const handleNoInteraction = () => {
    noClickCount++;
    

    const msgIndex = Math.min(noClickCount, messages.length - 1);
    btnNo.textContent = messages[msgIndex];
    

    const currentScale = 1 + (noClickCount * 0.2);
    btnYes.style.transform = `scale(${currentScale})`;
    
    moveNoButton();
};


btnNo.addEventListener('mouseover', () => {



    if (Math.random() > 0.3) {
        moveNoButton();
    }
});


btnNo.addEventListener('click', handleNoInteraction);



btnYes.addEventListener('click', () => {

    playMusic();
    

    questionContainer.style.opacity = '0';
    
    setTimeout(() => {
        questionContainer.classList.add('hidden');
        successContainer.classList.remove('hidden');
        

        requestAnimationFrame(() => {
            successContainer.classList.remove('opacity-0', 'scale-90');
            successContainer.classList.add('opacity-100', 'scale-100');
        });
        

        triggerConfetti();
        
    }, 500);
});
