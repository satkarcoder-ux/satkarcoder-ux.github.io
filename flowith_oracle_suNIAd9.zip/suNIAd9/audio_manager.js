const toggleBtn = document.getElementById('music-toggle');
let isPlaying = false;
let audio = new Audio('https://cdn.pixabay.com/download/audio/2022/10/25/audio_1e3752e245.mp3?filename=romantic-piano-125026.mp3'); 

audio.loop = true;
audio.volume = 0.5;

function updateIcon() {
    const icon = toggleBtn.querySelector('svg');
    toggleBtn.innerHTML = ''; // Clear current icon
    

    const iconName = isPlaying ? 'volume-2' : 'volume-x';
    const i = document.createElement('i');
    i.setAttribute('data-lucide', iconName);
    toggleBtn.appendChild(i);
    lucide.createIcons();
}

toggleBtn.addEventListener('click', () => {
    if (isPlaying) {
        audio.pause();
    } else {
        audio.play().catch(e => console.log("Audio autoplay blocked needed interaction", e));
    }
    isPlaying = !isPlaying;
    updateIcon();
});


updateIcon();

export const playMusic = () => {
    if (!isPlaying) {
        audio.play();
        isPlaying = true;
        updateIcon();
    }
};
