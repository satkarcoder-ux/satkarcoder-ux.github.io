/**
 * Canvas Background Animation (Bokeh/Floating Hearts)
 */

const canvas = document.getElementById('bg-canvas');
const ctx = canvas.getContext('2d');

let width, height;
let particles = [];

function resize() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
}

class Particle {
    constructor() {
        this.reset();
    }

    reset() {
        this.x = Math.random() * width;
        this.y = Math.random() * height + height; // Start below
        this.r = Math.random() * 15 + 5; // Radius
        this.speed = Math.random() * 1 + 0.5;
        this.opacity = Math.random() * 0.5 + 0.1;
        this.oscillation = Math.random() * 2; // For swaying
        this.angle = Math.random() * Math.PI * 2;
        this.color = Math.random() > 0.5 ? '244, 63, 94' : '251, 113, 133'; // rose-500 or rose-400
    }

    update() {
        this.y -= this.speed;
        this.x += Math.sin(this.angle) * 0.5;
        this.angle += 0.01;

        if (this.y < -50) {
            this.reset();
        }
    }

    draw() {
        ctx.beginPath();


        ctx.fillStyle = `rgba(${this.color}, ${this.opacity})`;
        ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
        ctx.fill();
        

        if (this.r > 12) {

        }
    }
}

function initParticles() {
    particles = [];
    const count = window.innerWidth < 768 ? 20 : 50; // Fewer on mobile
    for (let i = 0; i < count; i++) {
        const p = new Particle();
        p.y = Math.random() * height; // Start visible
        particles.push(p);
    }
}

function animate() {
    ctx.clearRect(0, 0, width, height);
    particles.forEach(p => {
        p.update();
        p.draw();
    });
    requestAnimationFrame(animate);
}


resize();
window.addEventListener('resize', () => {
    resize();
    initParticles();
});
initParticles();
animate();


/**
 * Confetti Exports
 */
export function triggerConfetti() {
    const duration = 5 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 100 };

    function randomInRange(min, max) {
        return Math.random() * (max - min) + min;
    }

    const interval = setInterval(function() {
        const timeLeft = animationEnd - Date.now();

        if (timeLeft <= 0) {
            return clearInterval(interval);
        }

        const particleCount = 50 * (timeLeft / duration);

        confetti(Object.assign({}, defaults, { particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } }));
        confetti(Object.assign({}, defaults, { particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } }));
    }, 250);
}
